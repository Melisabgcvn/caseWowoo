import numpy as np
import dnnlib
import dnnlib.tflib as tflib
import PIL.Image as pil
import pickle

def age_face(image_path, Gs):
    # Load image
    img = np.array(pil.open(image_path))
    # Resize image to match StyleGAN's expected size
    img = np.transpose(img, (2, 0, 1))
    img = np.expand_dims(img, axis=0)
    
    # Generate aged image
    result = Gs.run(img, None, truncation_psi=0.7, randomize_noise=False, output_transform=dict(func=tflib.convert_images_to_uint8))
    aged_img = pil.fromarray(result[0])
    
    return aged_img

# Örnek kullanım
model_path = "ffhq.pkl"  # İndirdiğiniz pre-trained modelin yolunu belirtin
image_path = "/Users/melisabagcivan/Desktop/case/images-2.jpeg"  # Yaşlandırmak istediğiniz giriş resminin yolunu belirtin

# StyleGAN modelini yükle
tflib.init_tf()
_G, _D, Gs = pickle.load(open(model_path, "rb"))

# Yüzü yaşlandır
aged_image = age_face(image_path, Gs)

# Sonucu kaydet
aged_image.save("aged_image.jpg")
